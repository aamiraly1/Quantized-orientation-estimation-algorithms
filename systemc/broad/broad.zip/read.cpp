#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class IMUDataset
{
public:
    int row_count;
    double **gyr;
    double **acc;
    double **mag;
    double **quat;
    double **pos;
    double gyrMin;
    double gyrMax;
    double accMin;
    double accMax;
    double magMin;
    double magMax;
    double quatMin;
    double quatMax;
    double posMin;
    double posMax;
    string filename;

    IMUDataset(string filename)
    {
        // Assume DOUBLE_MAX and DOUBLE_MIN 9999999.0 and -9999999.0
        // https://stackoverflow.com/a/48635448 better way to do it
        // Or select the first element as max and min
        this->filename = filename;
        gyrMin = accMin = magMin = quatMin = posMin = 9999999.0;
        gyrMax = accMax = magMax = quatMax = posMax = -9999999.0;
        ifstream file(filename);
        file >> row_count;
        read(file, gyr, 3, gyrMin, gyrMax);
        read(file, acc, 3, accMin, accMax);
        read(file, mag, 3, magMin, magMax);
        read(file, quat, 4, quatMin, quatMax);
        read(file, pos, 3, posMin, posMax);
        file.close();
    }
    ~IMUDataset()
    {
        for (int i = 0; i < row_count; i++)
        {
            delete[] gyr[i];
            delete[] acc[i];
            delete[] mag[i];
            delete[] quat[i];
            delete[] pos[i];
        }
        delete[] gyr;
        delete[] acc;
        delete[] mag;
        delete[] quat;
        delete[] pos;
    }

    friend ostream &operator<<(ostream &os, const IMUDataset &dataset)
    {
        os << dataset.filename << ":" << dataset.row_count << " rows" << endl;
        os << "gyrMin: " << dataset.gyrMin << endl;
        os << "gyrMax: " << dataset.gyrMax << endl;
        os << "accMin: " << dataset.accMin << endl;
        os << "accMax: " << dataset.accMax << endl;
        os << "magMin: " << dataset.magMin << endl;
        os << "magMax: " << dataset.magMax << endl;
        os << "quatMin: " << dataset.quatMin << endl;
        os << "quatMax: " << dataset.quatMax << endl;
        os << "posMin: " << dataset.posMin << endl;
        os << "posMax: " << dataset.posMax << endl;
        os << endl;
        return os;
    }

private:
    void read(ifstream &file, double **&array, int col_count, double &min, double &max)
    {
        array = new double *[row_count];
        for (int i = 0; i < row_count; i++)
        {
            array[i] = new double[col_count];
            for (int j = 0; j < col_count; j++)
            {
                file >> array[i][j];
                if (file.fail())
                    cout << i << ", " << j << " " << array << endl;

                if (array[i][j] < min)
                    min = array[i][j];
                if (array[i][j] > max)
                    max = array[i][j];
            }
        }
    }
};

int main(int argc, char const *argv[])
{
    IMUDataset dataset1("01.dat");
    IMUDataset dataset2("02.dat");
    IMUDataset dataset3("03.dat");
    cout << dataset1;
    cout << dataset2;
    cout << dataset3;
    return 0;
}
